# SCSIM — supply chain simulation library and stress-test framework.
# Copyright (c) 2023-2026 Phu Nguyen. All rights reserved until the open-access
# release; see scsim/NOTICE.md for licensing, funding and citation.
# Developed in part within the ACCURATE project (Horizon Europe, GA 101138269).

"""Generalized event injector — Part III §3.7.

Compile-time: validates targets/effects against the network (capacity_reduction
on a supplier needs a finite supplier capacity; a node:plant target throttles
or halts the plant's own production; a node:material target must be one of the
network's materials — every one of which has a qualified supplier by `Network`'s
own validation, and a made-in-house sub-assembly is a product, not a material).

Replication-time: draws stochastic fields from the hazard streams keyed by
(event_rep, event_index) and resolves targets to supplier indices.
edge:lane targets resolve to the lane's supplier while edges are
behavior-neutral (v1) — golden trace #5 asserts the equivalence.

Invariants: under ``queue`` overflow units are delayed, never destroyed;
same-target events compose by per-week max severity (min capacity factor,
max deferral end) — implemented in the engine's week_start mechanic.
"""
from __future__ import annotations

import numpy as np

from scsim.core.context import CompiledModel, ResolvedEvent
from scsim.entities.disruption import DisruptionEvent, DurationRange
from scsim.entities.enums import EffectType, TargetType
from scsim.stats.seeds import HAZARD_DURATION, HAZARD_START, hazard_rng


class DisruptionCompileError(ValueError):
    pass


def validate_events(model: CompiledModel) -> None:
    for i, ev in enumerate(model.scenario.events):
        if ev.target_type == TargetType.NODE_PLANT:
            # The plant's production capacity is always finite (products carry a
            # production_capacity), so capacity_reduction is always meaningful —
            # no supplier resolution or finiteness check needed.
            continue
        if ev.target_type == TargetType.NODE_MATERIAL:
            _resolve_material(model, ev, i)
            continue
        sup_idx = _resolve_supplier(model, ev, i)
        if ev.effect_type == EffectType.CAPACITY_REDUCTION and not np.isfinite(
            model.sup_capacity[sup_idx]
        ):
            raise DisruptionCompileError(
                f"event[{i}]: capacity_reduction on supplier "
                f"{model.sup_ids[sup_idx]!r} requires a finite supplier capacity_per_week "
                f"(§3.5 — ∞ has no flow to throttle)"
            )


def _resolve_supplier(model: CompiledModel, ev: DisruptionEvent, i: int) -> int:
    if ev.target_type == TargetType.NODE_SUPPLIER:
        if ev.target_id not in model.sup_index:
            raise DisruptionCompileError(f"event[{i}]: unknown supplier {ev.target_id!r}")
        return model.sup_index[ev.target_id]
    if ev.target_type == TargetType.EDGE_LANE:
        if ev.target_id not in model.lane_supplier:
            raise DisruptionCompileError(f"event[{i}]: unknown lane {ev.target_id!r}")
        return model.lane_supplier[ev.target_id]
    raise DisruptionCompileError(f"event[{i}]: unsupported target_type {ev.target_type}")


def _resolve_material(model: CompiledModel, ev: DisruptionEvent, i: int) -> int:
    if ev.target_id not in model.mat_index:
        raise DisruptionCompileError(f"event[{i}]: unknown material {ev.target_id!r}")
    return model.mat_index[ev.target_id]


def any_stochastic(events: list[DisruptionEvent]) -> bool:
    return any(e.is_stochastic for e in events)


def resolve_events(
    model: CompiledModel,
    warmup_end: int,
    event_rep: int,
    shifts: dict[int, tuple[int, int]] | None = None,
) -> list[ResolvedEvent]:
    """Draw start/duration per event and bind targets for one replication."""
    resolved: list[ResolvedEvent] = []
    seed = model.settings.project_seed
    for i, ev in enumerate(model.scenario.events):
        is_plant = ev.target_type == TargetType.NODE_PLANT
        is_material = ev.target_type == TargetType.NODE_MATERIAL
        mat_idx = _resolve_material(model, ev, i) if is_material else -1
        sup_idx = -1 if (is_plant or is_material) else _resolve_supplier(model, ev, i)
        if ev.start is not None:
            # `start` is an ABSOLUTE week (manuscript §3.7 — t* is absolute, and
            # the auto branch below draws an absolute week too). A fixed start
            # before t_w lay wholly or partly in warm-up, which no KPI measures:
            # the default "day 10" disruption was a no-disruption run with a
            # fabricated recovery time (audit F-03). It is moved to t_w, the
            # auto branch's own lower bound, and the caller is told — the engine
            # counts it (`ScenarioResult.event_shifts`) and the bridge surfaces
            # it in `mapping_warnings`. Shifted, never silently excluded.
            start = ev.start
            if start < warmup_end:
                start = warmup_end
                if shifts is not None:
                    shifts[i] = (int(ev.start), int(warmup_end))
        else:
            # Steady state: U{t_w .. t_w+2} (§3.7 — manuscript U{85..87}).
            rng = hazard_rng(seed, event_rep, i, HAZARD_START)
            start = int(rng.integers(warmup_end, warmup_end + 3))
        if isinstance(ev.duration, DurationRange):
            rng = hazard_rng(seed, event_rep, i, HAZARD_DURATION)
            duration = int(rng.integers(ev.duration.min, ev.duration.max + 1))
        else:
            duration = int(ev.duration)
        resolved.append(
            ResolvedEvent(
                supplier_idx=sup_idx,
                effect=ev.effect_type,
                start=start,
                end=start + duration,
                capacity_factor=ev.capacity_factor,
                overflow_rule=ev.overflow_rule,
                onset_profile=ev.onset_profile,
                recovery_profile=ev.recovery_profile,
                ramp_weeks=ev.ramp_weeks,
                is_plant=is_plant,
                material_idx=mat_idx,
            )
        )
    return resolved
